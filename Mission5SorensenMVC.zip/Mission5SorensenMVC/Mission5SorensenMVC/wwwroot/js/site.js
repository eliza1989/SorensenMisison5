﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
function calculateCost() {
    var holes = parseInt($("#holes").val());
    var rounds = parseInt($("#rounds").val());
    var total = 0;
    var sTotoal = ""

    if (rounds < 1 || isNaN(rounds)) {
        alert('Please enter a valid number rounds');
    }
    else if (holes !== 9 && holes !== 18 || isNaN(holes)){
        alert('Please enter a valid number holes (9 or 18 holes)');
    }
    else if (holes == 9) {
        total = 50 * rounds;
    }
    else {
        total = 75 * rounds;
    }

    sTotal = 'Total: $' + total.toFixed(0);
    document.getElementById("total").textContent=sTotal

}